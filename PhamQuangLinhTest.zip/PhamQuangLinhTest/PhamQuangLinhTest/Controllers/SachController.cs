﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PhamQuangLinhTest.Models;

namespace PhamQuangLinhTest.Controllers
{
    public class SachController : Controller
    {
        private BookStoreEntities db = new BookStoreEntities();

        // GET: Saches
        public ActionResult Index()
        {
            ViewBag.Saches =  db.Saches.ToList();
            return View();
        }

        // GET: Saches/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Sach sach = db.Saches.Find(id);
            if (sach == null)
            {
                return HttpNotFound();
            }
            return View(sach);
        }

        // GET: Saches/Create
        public ActionResult Create()
        {
            ViewBag.ChuDes = new SelectList(db.ChuDes, "ChuDeID", "TenChuDe");
            ViewBag.NhaXuatBans = new SelectList(db.NhaXuatBans, "NhaXuatBanID", "TenNhaXuatBan");
            return View();
        }

        // POST: Saches/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "SachID,Ten,GiaBan,ChuDeID,NhaXuatBanID,MoTa,SoTrang,NgayCapNhat")] Sach sach)
        {
            if (ModelState.IsValid)
            {
                sach.NgayCapNhat = DateTime.Now;
                db.Saches.Add(sach);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ChuDes = new SelectList(db.ChuDes, "ChuDeID", "TenChuDe", sach.ChuDeID);
            ViewBag.NhaXuatBans = new SelectList(db.NhaXuatBans, "NhaXuatBanID", "TenNhaXuatBan", sach.NhaXuatBanID);
            return View(sach);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Sach sach = db.Saches.Find(id);
            if (sach == null)
            {
                return HttpNotFound();
            }
            return View(sach);
        }

        // POST: Saches/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Sach sach = db.Saches.Find(id);
            db.Saches.Remove(sach);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
